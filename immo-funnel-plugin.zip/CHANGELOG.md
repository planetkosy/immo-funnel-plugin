# Changelog

## [1.1] - 2024-11-23
### Added
- Einstellungsseite im WordPress-Admin-Bereich für die Konfiguration des Plugins.
- Eine direkte Berarbeitung der `immo-funnel-config.php` zur Anpassung der Konfiguration ist nicht mehr nötig.
- "Einstellungen"-Link in der Plugin-Übersicht.
- "Immo-Funnel"-Eintrag im Navigationsmenü

---

## [1.0] - 2024-11-20
- Erste Veröffentlichung des Plugins.

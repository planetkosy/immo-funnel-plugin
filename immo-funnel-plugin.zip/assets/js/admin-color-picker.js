jQuery(document).ready(function ($) {
    $('.immo-funnel-color-field').wpColorPicker();
});
